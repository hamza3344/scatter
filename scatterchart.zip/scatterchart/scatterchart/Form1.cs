﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ScottPlot;

namespace scatterchart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            var plt = new ScottPlot.Plot(750, 400);
            int pointcount = 60;
            double[] x = DataGen.Consecutive(pointcount);
            double[] sin = DataGen.Sin(pointcount);
            double[] cos = DataGen.Cos(pointcount);
            plt.Style(Style.Seaborn);
            plt.Palette = Palette.Amber;
            plt.Title("My chart");
            plt.XLabel("x-axis");
            plt.YLabel("Y-axis");
            plt.AddScatterPoints(x, sin);
            plt.AddScatter(x, cos);
            plt.SaveFig("scater.png");
            pictureBox1.ImageLocation = "scater.png";
            
        }
    }
}
